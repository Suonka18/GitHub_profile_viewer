import React, { useState } from 'react';
import axios from 'axios';
import { Container, Typography, Alert, Box, AppBar, Toolbar } from '@mui/material';
import SearchBar from './Components/SearchBar/SearchBar';
import UserProfile from './Components/UserProfile/UserProfile';
import RepoList from './Components/RepoList/RepoList';

function App() {
  const [userData, setUserData] = useState(null);
  const [repos, setRepos] = useState([]);
  const [error, setError] = useState('');

  const handleSearch = async (username) => {
    try {
      setError('');
      setUserData(null);
      setRepos([]);

      const headers = {
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28'
      };

      const userRes = await axios.get(`https://api.github.com/users/${username}`, { headers });
      setUserData(userRes.data);

      const repoRes = await axios.get(`https://api.github.com/users/${username}/repos`, { headers });
      setRepos(repoRes.data);

    } catch (err) {
      console.error(err);
      setError('User not found, API limit exceeded, or request blocked by GitHub');
    }
  };

  return (
    <Box sx={{ backgroundColor: '#f0f0f0', minHeight: '100vh' }}>
      
    <AppBar position="static" sx={{ backgroundColor: '#003366' }}>
    <Toolbar>
      <Typography 
        variant="h6"
        component="a"
        href="https://github.com"
        target="_blank"
        rel="noopener noreferrer"
        sx={{ 
          // fontFamily: 'Roboto Slab, serif', 
          fontWeight: 'bold',
          color: '#fff',
          textDecoration: 'none',
          '&:hover': {
            textDecoration: 'underline',
          }
        }}
      >
        GitHub
      </Typography>
    </Toolbar>
  </AppBar>


      {/* Main content */}
      <Container sx={{ mt: 4 }}>
        <Box 
          sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center', 
            maxWidth: '600px', 
            mx: 'auto' 
          }}
        >
          <Typography 
            variant="h4" 
            gutterBottom 
            sx={{ 
              color: '#003366',              
              fontFamily: 'Roboto Slab, serif',
              fontWeight: 'bold',
              fontSize: '2.5rem'
            }}
          >
            GitHub Profile Viewer
          </Typography>

          <SearchBar onSearch={handleSearch} />
          {error && <Alert severity="error" sx={{ width: '100%', mb: 2 }}>{error}</Alert>}
          {userData && <UserProfile user={userData} />}
          {repos.length > 0 && <RepoList repos={repos} />}
        </Box>
      </Container>
    </Box>
  );
}

export default App;
