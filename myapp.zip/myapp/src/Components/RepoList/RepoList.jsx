import React from 'react';
import {List, ListItem, ListItemText, ListItemIcon, Divider, Typography} from '@mui/material';
import StarIcon from '@mui/icons-material/Star';
import ForkRightIcon from '@mui/icons-material/ForkRight';

function RepoList({ repos }) {
  return (
    <div>
      <Typography variant="h6" sx={{ mb: 2 }}>Repositories</Typography>
      <List sx={{ maxWidth: 600, mx: 'auto' }}>
        {repos.map((repo) => (
          <div key={repo.id}>
            <ListItem
              component="a"
              href={repo.html_url}
              target="_blank"
              rel="noopener noreferrer"
              sx={{ display: 'flex', justifyContent: 'space-between' }}
            >
              <ListItemText primary={repo.name} />
              <ListItemIcon sx={{ minWidth: 'auto', display: 'flex', gap: 1 }}>
                <StarIcon fontSize="small" sx={{ color: '#FFD700' }}/> <Typography variant="caption">{repo.stargazers_count}</Typography>
                <ForkRightIcon fontSize="small" sx={{ color: '#003366 ' }} /> <Typography variant="caption">{repo.forks_count}</Typography>
              </ListItemIcon>
            </ListItem>
            <Divider />
          </div>
        ))}
      </List>
    </div>
  );
}

export default RepoList;
