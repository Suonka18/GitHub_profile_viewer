
import React from 'react';
import { Card, CardContent, Typography, Avatar, Box } from '@mui/material';

function UserProfile({ user }) {
  return (
    <Card sx={{ maxWidth: 400, mx: 'auto', mb: 4 }}>
      <CardContent sx={{ textAlign: 'center' }}>
        <Avatar
          src={user.avatar_url}
          alt={user.login}
          sx={{ width: 100, height: 100, mx: 'auto', mb: 2 }}
        />
        
        <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
          {user.name || user.login}
        </Typography>
        
        {user.bio ? (
          <Typography 
            variant="body2" 
            color="text.secondary" 
            sx={{ mt: 1, mb: 1, fontStyle: 'italic' }}
          >
            {user.bio}
          </Typography>
        ) : (
          <Typography 
            variant="body2" 
            color="text.secondary" 
            sx={{ mt: 1, mb: 1, fontStyle: 'italic' }}
          >
            No bio available.
          </Typography>
        )}

        {user.email && (
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            📧 {user.email}
          </Typography>
        )}

        <Box sx={{ mt: 1 }}>
          <Typography variant="caption">
            Followers: {user.followers}
          </Typography>
          {' | '}
          <Typography variant="caption">
            Following: {user.following}
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
}

export default UserProfile;

